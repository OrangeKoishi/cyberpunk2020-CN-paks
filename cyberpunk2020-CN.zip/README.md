# Here is the working module for your translation!

Please take time todo some adjustments:

* Change the ID of the module (currently `your-module-id`)
    * In the `module.json` file: `"id": "your-module-id"`
    * In the `register.js` file: `const MODULE_ID = 'your-module-id'; // Change this ID!`
    * The name of this directory
* Customize the name and the description of the module and your name in the `module.json`

Feel free to make any changes you want.

Once all is done, all you have to do now is to move it into your Foundry `modules/` directory and activate it in a
world.
